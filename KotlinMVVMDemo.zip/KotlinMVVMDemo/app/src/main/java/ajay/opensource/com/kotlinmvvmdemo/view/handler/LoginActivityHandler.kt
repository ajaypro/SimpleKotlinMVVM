package ajay.opensource.com.kotlinmvvmdemo.view.handler

import android.view.View

interface LoginActivityHandler {
    fun onLoginClick(view: View)
    fun onRegisterClick(view: View)
}