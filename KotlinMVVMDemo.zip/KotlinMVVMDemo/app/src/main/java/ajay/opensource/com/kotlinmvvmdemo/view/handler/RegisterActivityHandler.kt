package ajay.opensource.com.kotlinmvvmdemo.view.handler


import android.view.View

interface RegisterActivityHandler{
    fun onRegisterClick(view: View)
}